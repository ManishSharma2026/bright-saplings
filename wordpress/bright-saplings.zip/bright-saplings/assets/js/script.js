/* ============================================================
   BRIGHT SAPLINGS DAYCARE — script.js
   Vanilla JS, no dependencies. Runs with `defer`.

   01. Setup & helpers
   02. Footer year
   03. Sticky header state + scroll progress bar
   04. Mobile navigation drawer
   05. Smooth scroll with header offset
   06. Scroll-spy (highlight the section you're in)
   07. Reveal on scroll + stagger
   08. Hero stat count-up
   09. Contact form validation  <-- plug your backend in here
   10. Magnetic buttons
   11. Pointer tilt on cards
   12. Parallax scene (scroll + pointer)
   13. Heading line-splitting
   14. The rotating menu (Food section)

   MOTION POLICY
   Sections 10-13 are decoration. Every one of them checks
   prefers-reduced-motion and bails out, and 10-12 also bail on
   touch-only devices where there is no pointer to follow. Nothing
   in here is required for the page to work or be readable.
   ============================================================ */

(function () {
  'use strict';

  /* ---------- 01. SETUP & HELPERS -------------------------- */
  var $  = function (sel, ctx) { return (ctx || document).querySelector(sel); };
  var $$ = function (sel, ctx) { return Array.prototype.slice.call((ctx || document).querySelectorAll(sel)); };

  var motionQuery  = window.matchMedia('(prefers-reduced-motion: reduce)');
  var reduceMotion = motionQuery.matches;
  var finePointer  = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
  var isDesktop    = function () { return window.matchMedia('(min-width: 860px)').matches; };

  // Decoration only runs when it is both wanted and useful
  var allowFancy = !reduceMotion && finePointer;

  var lerp = function (a, b, t) { return a + (b - a) * t; };
  var clamp = function (v, lo, hi) { return Math.min(hi, Math.max(lo, v)); };

  document.documentElement.classList.remove('no-js');

  // If someone flips the OS setting mid-visit, stop animating immediately.
  if (motionQuery.addEventListener) {
    motionQuery.addEventListener('change', function (e) {
      reduceMotion = e.matches;
      allowFancy = !reduceMotion && finePointer;
      if (reduceMotion) {
        $$('.parallax').forEach(function (el) {
          el.style.setProperty('--py', '0px');
          el.style.setProperty('--px', '0px');
        });
        $$('[data-tilt]').forEach(function (el) {
          el.style.setProperty('--rx', '0deg');
          el.style.setProperty('--ry', '0deg');
        });
      }
    });
  }


  /* ---------- 02. FOOTER YEAR ------------------------------ */
  var yearEl = $('#year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();


  /* ---------- 03. STICKY HEADER + PROGRESS BAR ------------- */
  var header   = $('#siteHeader');
  var progress = $('#scrollProgress');


  /* ---------- 04. MOBILE NAV DRAWER ------------------------ */
  var nav    = $('#primaryNav');
  var toggle = $('#navToggle');
  var scrim  = $('#navScrim');

  function setNav(open) {
    if (!nav || !toggle) return;
    nav.classList.toggle('is-open', open);
    toggle.setAttribute('aria-expanded', String(open));
    toggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    document.body.classList.toggle('is-locked', open);
    if (scrim) scrim.hidden = !open;
  }

  if (toggle) {
    toggle.addEventListener('click', function () {
      setNav(toggle.getAttribute('aria-expanded') !== 'true');
    });
  }

  if (scrim) scrim.addEventListener('click', function () { setNav(false); });

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') setNav(false);
  });

  window.addEventListener('resize', function () {
    if (isDesktop()) setNav(false);
  });


  /* ---------- 05. SMOOTH SCROLL ---------------------------- */
  $$('a[href^="#"]').forEach(function (link) {
    link.addEventListener('click', function (e) {
      var id = link.getAttribute('href');
      if (!id || id === '#') return;

      var target = document.getElementById(id.slice(1));
      if (!target) return;

      e.preventDefault();
      setNav(false);

      var headerH = header ? header.offsetHeight : 0;
      var top = target.getBoundingClientRect().top + window.pageYOffset - headerH - 18;

      window.scrollTo({ top: top, behavior: reduceMotion ? 'auto' : 'smooth' });

      target.setAttribute('tabindex', '-1');
      target.focus({ preventScroll: true });

      if (history.pushState) history.pushState(null, '', id);
    });
  });


  /* ---------- 06. SCROLL-SPY ------------------------------- */
  var navLinks = $$('.nav__link');
  var sections = navLinks
    .map(function (l) { return document.getElementById(l.getAttribute('href').slice(1)); })
    .filter(Boolean);

  if ('IntersectionObserver' in window && sections.length) {
    var spy = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        navLinks.forEach(function (l) {
          l.classList.toggle('is-active', l.getAttribute('href') === '#' + entry.target.id);
        });
      });
    }, { rootMargin: '-45% 0px -50% 0px', threshold: 0 });

    sections.forEach(function (s) { spy.observe(s); });
  }


  /* ---------- 07. REVEAL ON SCROLL + STAGGER --------------- */
  // Children of .stagger get their index written to --i so the CSS
  // can offset each one's transition-delay.
  $$('.stagger').forEach(function (group) {
    Array.prototype.forEach.call(group.children, function (child, i) {
      child.style.setProperty('--i', i);
    });
  });

  var revealEls = $$('.reveal, .stagger');

  if (reduceMotion || !('IntersectionObserver' in window)) {
    revealEls.forEach(function (el) { el.classList.add('is-visible'); });
  } else {
    var revealObserver = new IntersectionObserver(function (entries, obs) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('is-visible');
        obs.unobserve(entry.target);
      });
    }, { rootMargin: '0px 0px -6% 0px', threshold: 0.06 });

    revealEls.forEach(function (el) { revealObserver.observe(el); });
  }


  /* ---------- 08. HERO STAT COUNT-UP ----------------------- */
  var nums = $$('.hero__stats .num');

  function countUp(el) {
    var target = parseInt(el.getAttribute('data-count'), 10);
    if (isNaN(target)) return;

    var prefix   = el.getAttribute('data-prefix') || '';
    var duration = 1200;
    var start    = null;

    function step(ts) {
      if (start === null) start = ts;
      var p = Math.min((ts - start) / duration, 1);
      var eased = 1 - Math.pow(1 - p, 3);          // easeOutCubic
      el.textContent = prefix + Math.round(target * eased);
      if (p < 1) window.requestAnimationFrame(step);
    }

    window.requestAnimationFrame(step);
  }

  if (!reduceMotion && 'IntersectionObserver' in window && nums.length) {
    var numObserver = new IntersectionObserver(function (entries, obs) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        countUp(entry.target);
        obs.unobserve(entry.target);
      });
    }, { threshold: 0.6 });

    nums.forEach(function (n) { numObserver.observe(n); });
  }


  /* ---------- 09. CONTACT FORM ----------------------------- *
   * Frontend only right now. Nothing is sent anywhere.
   *
   * TO MAKE IT ACTUALLY SEND, pick one:
   *
   *  A) Formspree / Basin / Getform — easiest, no code:
   *     add   action="https://formspree.io/f/YOUR_ID"  method="POST"
   *     to the <form> in the HTML and delete this whole handler.
   *
   *  B) Netlify Forms — add  netlify  and a hidden form-name input
   *     to the <form>, then delete this handler.
   *
   *  C) Your own endpoint — replace the SIMULATED SUCCESS block below
   *     with a real fetch(). The commented example shows the shape.
   *
   *  On WordPress, use a form plugin instead — see wordpress/README.md.
   * -------------------------------------------------------- */
  var form   = $('#tourForm');
  var status = $('#formStatus');

  if (form) {
    var emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
    var phoneRe = /^[\d\s()+.\-]{7,20}$/;

    function setError(name, msg) {
      var input = form.elements[name];
      var slot  = form.querySelector('[data-error-for="' + name + '"]');
      if (slot) slot.textContent = msg || '';
      if (input) {
        if (msg) input.setAttribute('aria-invalid', 'true');
        else input.removeAttribute('aria-invalid');
      }
      return !msg;
    }

    function validate() {
      var ok = true;

      var name = form.elements.parentName.value.trim();
      ok = setError('parentName', name.length < 2 ? 'Please tell us your name.' : '') && ok;

      var email = form.elements.email.value.trim();
      if (!email)                    ok = setError('email', 'We need an email to reply to.') && ok;
      else if (!emailRe.test(email)) ok = setError('email', 'That email doesn\'t look right.') && ok;
      else                           setError('email', '');

      var phone = form.elements.phone.value.trim();
      if (phone && !phoneRe.test(phone)) ok = setError('phone', 'Check the phone number format.') && ok;
      else setError('phone', '');

      return ok;
    }

    ['parentName', 'email', 'phone'].forEach(function (n) {
      var el = form.elements[n];
      if (el) el.addEventListener('input', function () { setError(n, ''); });
    });

    form.addEventListener('submit', function (e) {
      e.preventDefault();

      if (status) { status.textContent = ''; status.className = 'form__status'; }

      if (!validate()) {
        if (status) {
          status.textContent = 'Please fix the highlighted fields.';
          status.className = 'form__status is-err';
        }
        var firstBad = form.querySelector('[aria-invalid="true"]');
        if (firstBad) firstBad.focus();
        return;
      }

      var data = {
        parentName: form.elements.parentName.value.trim(),
        email:      form.elements.email.value.trim(),
        phone:      form.elements.phone.value.trim(),
        childAge:   form.elements.childAge.value,
        startDate:  form.elements.startDate.value,
        days:       $$('input[name="days"]:checked', form).map(function (c) { return c.value; }),
        message:    form.elements.message.value.trim()
      };

      /* --- C) REAL SUBMISSION would go here -------------------
      var btn = form.querySelector('button[type="submit"]');
      btn.disabled = true;
      btn.textContent = 'Sending…';

      fetch('https://your-endpoint.example/tour-request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      })
        .then(function (r) { if (!r.ok) throw new Error('Bad response'); return r.json(); })
        .then(function () { showSuccess(); })
        .catch(function () {
          status.textContent = 'Something went wrong — please call us on 425-428-9660.';
          status.className = 'form__status is-err';
        })
        .finally(function () { btn.disabled = false; btn.textContent = 'Send request'; });
      return;
      -------------------------------------------------------- */

      // --- SIMULATED SUCCESS (remove once a backend is wired up) ---
      console.log('Tour request (not sent anywhere yet):', data);
      showSuccess();
    });

    function showSuccess() {
      if (status) {
        status.textContent = 'Thanks! Your request is in — we\'ll reply within one business day.';
        status.className = 'form__status is-ok';
      }
      form.reset();
      ['parentName', 'email', 'phone'].forEach(function (n) { setError(n, ''); });
    }
  }


  /* ---------- 10. MAGNETIC BUTTONS -------------------------
     The button drifts a few pixels toward the cursor while it is
     nearby. Capped at 6px — enough to feel responsive, not enough
     to make the target move away from someone trying to click it. */
  if (allowFancy) {
    $$('[data-magnetic]').forEach(function (el) {
      var raf = null;
      var tx = 0, ty = 0, cx = 0, cy = 0;

      function run() {
        cx = lerp(cx, tx, .18);
        cy = lerp(cy, ty, .18);
        el.style.setProperty('--mx', cx.toFixed(2) + 'px');
        el.style.setProperty('--my', cy.toFixed(2) + 'px');
        if (Math.abs(cx - tx) > .1 || Math.abs(cy - ty) > .1) raf = requestAnimationFrame(run);
        else raf = null;
      }
      function kick() { if (raf === null) raf = requestAnimationFrame(run); }

      el.addEventListener('pointermove', function (e) {
        var r = el.getBoundingClientRect();
        tx = clamp((e.clientX - (r.left + r.width / 2)) * .28, -6, 6);
        ty = clamp((e.clientY - (r.top + r.height / 2)) * .38, -6, 6);
        kick();
      });

      el.addEventListener('pointerleave', function () { tx = 0; ty = 0; kick(); });
    });
  }


  /* ---------- 11. POINTER TILT ON CARDS --------------------
     Reads --tilt-max from the stylesheet so the ceiling stays a
     design decision rather than a magic number in here. */
  if (allowFancy) {
    var tiltMax = parseFloat(
      getComputedStyle(document.documentElement).getPropertyValue('--tilt-max')
    ) || 5;

    $$('[data-tilt]').forEach(function (card) {
      var raf = null, nx = 0, ny = 0;

      function apply() {
        card.style.setProperty('--ry', (nx * tiltMax).toFixed(2) + 'deg');
        card.style.setProperty('--rx', (-ny * tiltMax).toFixed(2) + 'deg');
        raf = null;
      }

      card.addEventListener('pointermove', function (e) {
        var r = card.getBoundingClientRect();
        nx = clamp((e.clientX - r.left) / r.width - .5, -.5, .5) * 2;
        ny = clamp((e.clientY - r.top) / r.height - .5, -.5, .5) * 2;
        if (raf === null) raf = requestAnimationFrame(apply);
      });

      card.addEventListener('pointerleave', function () {
        card.style.setProperty('--rx', '0deg');
        card.style.setProperty('--ry', '0deg');
      });
    });
  }


  /* ---------- 12. PARALLAX SCENE ---------------------------
     One rAF loop drives the header state, the progress bar and
     every .parallax layer. Layers move by data-depth * distance
     from the viewport centre, so the effect is self-limiting —
     nothing can drift off into space on a long page.

     Pointer drift is lerped separately so it eases rather than
     snapping to the cursor. */
  var layers = $$('.parallax').map(function (el) {
    return { el: el, depth: parseFloat(el.getAttribute('data-depth')) || 0, start: 0 };
  });

  /* Each layer's offset is measured from the scroll position where it
     first enters the viewport, so every layer sits at exactly 0 in its
     designed position on load. Measuring from the viewport centre
     instead would displace the hero before anyone has scrolled. */
  function measureLayers() {
    var y  = window.pageYOffset || document.documentElement.scrollTop;
    var vh = window.innerHeight;

    layers.forEach(function (layer) {
      layer.el.style.setProperty('--py', '0px');
      var top = layer.el.getBoundingClientRect().top + y;
      layer.start = Math.max(0, top - vh);
    });
  }

  var pointerX = 0, pointerY = 0;   // target, -1..1
  var driftX = 0, driftY = 0;       // eased

  if (allowFancy && layers.length) {
    window.addEventListener('pointermove', function (e) {
      pointerX = (e.clientX / window.innerWidth  - .5) * 2;
      pointerY = (e.clientY / window.innerHeight - .5) * 2;
    }, { passive: true });
  }

  var ticking = false;

  function frame() {
    var y = window.pageYOffset || document.documentElement.scrollTop;

    if (header) header.classList.toggle('is-stuck', y > 8);

    if (progress) {
      var max = document.documentElement.scrollHeight - window.innerHeight;
      progress.style.width = (max > 0 ? (y / max) * 100 : 0) + '%';
    }

    if (!reduceMotion && layers.length) {
      driftX = lerp(driftX, pointerX, .06);
      driftY = lerp(driftY, pointerY, .06);

      var vh = window.innerHeight;

      layers.forEach(function (layer) {
        var r = layer.el.getBoundingClientRect();

        // skip anything comfortably off screen
        if (r.bottom < -vh || r.top > vh * 2) return;

        // clamped so a long page can never fling a layer into orbit
        var py = clamp((y - layer.start) * layer.depth, -160, 160);
        var px = driftX * layer.depth * 42;
        var pyPointer = driftY * layer.depth * 26;

        layer.el.style.setProperty('--py', (py + pyPointer).toFixed(1) + 'px');
        layer.el.style.setProperty('--px', px.toFixed(1) + 'px');
      });
    }

    ticking = false;
  }

  function requestFrame() {
    if (!ticking) {
      window.requestAnimationFrame(frame);
      ticking = true;
    }
  }

  window.addEventListener('scroll', requestFrame, { passive: true });
  window.addEventListener('resize', function () {
    measureLayers();
    requestFrame();
  });

  if (layers.length) measureLayers();

  // The pointer drift needs its own heartbeat, otherwise the scene
  // freezes whenever the page is still. Only runs when it can matter.
  if (allowFancy && layers.length) {
    (function heartbeat() {
      if (Math.abs(driftX - pointerX) > .002 || Math.abs(driftY - pointerY) > .002) requestFrame();
      window.requestAnimationFrame(heartbeat);
    })();
  }

  requestFrame();


  /* ---------- 13. HEADING LINE-SPLIT -----------------------
     Wraps each visual line of a [data-split] heading in its own
     overflow-hidden mask, so the lines rise into place one after
     another. Runs only after the webfont has settled, because the
     line breaks depend on the real metrics — splitting against the
     fallback font would mask the wrong words. */
  function splitLines(el) {
    var original = el.getAttribute('data-text') || el.textContent.trim().replace(/\s+/g, ' ');
    el.setAttribute('data-text', original);

    // 1. one span per word so we can read their line positions
    el.innerHTML = original.split(' ').map(function (w) {
      return '<span class="w">' + w + '</span>';
    }).join(' ');

    var words = $$('.w', el);
    if (!words.length) return;

    // 2. group words by their offsetTop
    var lines = [], current = [], lineTop = null;

    words.forEach(function (w) {
      var top = w.offsetTop;
      if (lineTop === null) lineTop = top;
      if (Math.abs(top - lineTop) > 4) {
        lines.push(current);
        current = [];
        lineTop = top;
      }
      current.push(w.textContent);
    });
    if (current.length) lines.push(current);

    // 3. rebuild as masked lines.
    //    Joined with a newline so textContent keeps the word gap between
    //    lines — otherwise a screen reader (and copy-paste) runs the last
    //    word of one line into the first of the next.
    el.innerHTML = lines.map(function (line, i) {
      return '<span class="line-mask"><span style="--l:' + i + '">' +
             line.join(' ') + '</span></span>';
    }).join('\n');
  }

  var splitTargets = $$('[data-split]');

  function runSplit() {
    if (reduceMotion) return;
    splitTargets.forEach(splitLines);
  }

  if (splitTargets.length && !reduceMotion) {
    if (document.fonts && document.fonts.ready) {
      document.fonts.ready.then(runSplit).catch(runSplit);
    } else {
      window.addEventListener('load', runSplit);
    }

    // Re-split on a real width change — line breaks move with the
    // container. Height-only changes (mobile URL bar) are ignored.
    var lastWidth = window.innerWidth;
    var resizeTimer = null;

    window.addEventListener('resize', function () {
      if (window.innerWidth === lastWidth) return;
      lastWidth = window.innerWidth;
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(runSplit, 220);
    });
  }


  /* ---------- 14. THE ROTATING MENU ------------------------
     The four weeks live in the HTML as four <table> elements.
     With JavaScript off they all show, in order, and the page
     is still readable, crawlable and printable. This turns
     them into a tabbed viewer, works out which of the four
     weeks today falls in, and marks today's column.

     "Download / print" calls window.print(). Every browser
     offers "Save as PDF" from that dialog, so a parent gets a
     proper fridge menu with no plugin and no download library.
     08-print.css lays all four weeks out on one A4 sheet.     */

  /* The Monday that Week 1 started on. Change this and the
     "this week" marker re-anchors — no other edits needed. */
  var MENU_ANCHOR = '2026-01-05';

  var menuRoot = $('#menu');

  if (menuRoot) {
    var weekBlocks = $$('.menu__wk', menuRoot);
    var tabStrip   = $('#menuWeeks');
    var weekPane   = $('#menuWeek');
    var monthPane  = $('#menuMonth');
    var nowLabel   = $('#menuNow');
    var viewGroup  = $('#menuToggle');
    var printBtn   = $('#menuPrint');
    var DAYS       = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];

    /* --- which of the four weeks are we in? --- */
    function mondayOf(d) {
      var t = new Date(d.getFullYear(), d.getMonth(), d.getDate());
      var wd = (t.getDay() + 6) % 7;          // Mon = 0
      t.setDate(t.getDate() - wd);
      return t;
    }
    function currentWeekNo() {
      var parts = MENU_ANCHOR.split('-');
      var anchor = new Date(+parts[0], +parts[1] - 1, +parts[2]);
      var weeks = Math.floor((mondayOf(new Date()) - anchor) / 604800000);
      return ((weeks % 4) + 4) % 4 + 1;       // 1..4, correct for dates before the anchor too
    }

    var todayName = DAYS[(new Date().getDay() + 6) % 7] || null;  // null at weekends
    var liveWeek  = currentWeekNo();
    var shownWeek = liveWeek;
    var view      = 'week';

    /* --- build the week tabs --- */
    weekBlocks.forEach(function (block) {
      var n = block.getAttribute('data-week');
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'wk';
      btn.setAttribute('role', 'tab');
      btn.setAttribute('data-week', n);
      btn.innerHTML = 'Week ' + n +
        (n === String(liveWeek) ? ' <span class="wk__now" aria-hidden="true"></span>' : '');
      if (n === String(liveWeek)) btn.setAttribute('aria-label', 'Week ' + n + ', this week');
      btn.addEventListener('click', function () { showWeek(n); });
      tabStrip.appendChild(btn);
    });

    /* --- turn one week's table into day cards --- */
    function buildWeekPane(n) {
      var block = weekBlocks.filter(function (b) { return b.getAttribute('data-week') === String(n); })[0];
      if (!block) return;

      var heads = $$('thead th[data-day]', block).map(function (th) { return th.getAttribute('data-day'); });
      var rows  = $$('tbody tr', block).map(function (tr) {
        return {
          label: $('th', tr).textContent.trim(),
          cells: $$('td', tr).map(function (td) { return td.textContent.trim(); }),
          lunch: tr.classList.contains('row--lunch')
        };
      });

      weekPane.innerHTML = heads.map(function (day, i) {
        var isToday = day === todayName && String(n) === String(liveWeek);
        return '' +
          '<article class="day' + (isToday ? ' is-today' : '') + '">' +
            '<h3 class="day__name">' + day +
              (isToday ? '<span class="day__today">Today</span>' : '') +
            '</h3>' +
            '<dl class="day__meals">' +
              rows.map(function (r) {
                return '<div class="meal' + (r.lunch ? ' meal--lunch' : '') + '">' +
                         '<dt>' + r.label + '</dt>' +
                         '<dd>' + r.cells[i] + '</dd>' +
                       '</div>';
              }).join('') +
            '</dl>' +
          '</article>';
      }).join('');
    }

    /* --- mark today's column in the month tables --- */
    function markToday() {
      $$('[data-day]', monthPane).forEach(function (el) {
        var wk = el.closest('.menu__wk');
        var on = el.getAttribute('data-day') === todayName &&
                 wk && wk.getAttribute('data-week') === String(liveWeek);
        el.classList.toggle('is-today', !!on);
      });
    }

    function label() {
      if (!nowLabel) return;
      if (view === 'month') {
        nowLabel.innerHTML = 'All four weeks. We are currently on <b>week ' + liveWeek + '</b>.';
      } else if (String(shownWeek) === String(liveWeek)) {
        nowLabel.innerHTML = todayName
          ? 'This week at Bright Saplings &mdash; <b>week ' + liveWeek + '</b>, and today is ' + todayName + '.'
          : 'This week at Bright Saplings &mdash; <b>week ' + liveWeek + '</b>. Back Monday!';
      } else {
        nowLabel.innerHTML = 'Showing <b>week ' + shownWeek + '</b>. We are currently on week ' + liveWeek + '.';
      }
    }

    function showWeek(n) {
      shownWeek = n;
      $$('.wk', tabStrip).forEach(function (b) {
        b.setAttribute('aria-selected', b.getAttribute('data-week') === String(n) ? 'true' : 'false');
      });
      buildWeekPane(n);
      label();
    }

    function setView(next) {
      view = next;
      $$('button', viewGroup).forEach(function (b) {
        b.setAttribute('aria-pressed', b.getAttribute('data-view') === next ? 'true' : 'false');
      });
      weekPane.hidden  = next !== 'week';
      monthPane.hidden = next !== 'month';
      tabStrip.hidden  = next !== 'week';        // the tabs don't apply to the month view
      label();
    }

    if (viewGroup) {
      $$('button', viewGroup).forEach(function (b) {
        b.addEventListener('click', function () { setView(b.getAttribute('data-view')); });
      });
    }

    if (printBtn) {
      printBtn.addEventListener('click', function () { window.print(); });
    }

    markToday();
    showWeek(liveWeek);
    setView('week');
  }

})();
